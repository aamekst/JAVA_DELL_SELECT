package br.com.dell.beans;

public class Notebook extends Computador{
	
	private double tamanhoTela;

	public double getTamanhoTela() {
		return tamanhoTela;
	}

	public void setTamanhoTela(double tamanhoTela) {
		this.tamanhoTela = tamanhoTela;
	}

}
